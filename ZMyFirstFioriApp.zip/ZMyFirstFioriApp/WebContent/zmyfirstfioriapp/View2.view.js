sap.ui.jsview("zmyfirstfioriapp.View2", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zmyfirstfioriapp.View2
	*/ 
	getControllerName : function() {
		return "zmyfirstfioriapp.View2";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zmyfirstfioriapp.View2
	*/ 
	createContent : function(oController) {
		
		var oFooterToolbar = new sap.m.Toolbar("footerTblr",{
			content: [
			          new sap.m.ToolbarSpacer(),
			          new sap.m.Button({
			        	  text: "Approve",
			        	  type: "Accept",
			        	  press: [oController.approval,oController]
			          }),
			          new sap.m.Button("idRej",{
			        	  text: "Reject",
			        	  type: "Reject"
			          })
			          
			          ]
		});
		
		
 		return new sap.m.Page({
			title: "Second View",
			showNavButton: true,
			navButtonPress: oController.back,
			footer: oFooterToolbar,
			content: [
			          new sap.m.ObjectHeader({
			        	  title: "{name}",
			        	  intro: "{color}",
			        	  number: "{price}",
			        	  numberUnit: "{unit}",
			        	  icon: "{image}"
			          })
//			          new sap.m.Button("idBack",{
//			        	  text: "Back",
//			        	  icon: "sap-icon://arrow-left",
//			        	  press: oController.back
//			          })
			]
		});
	}

});