sap.ui.controller("zmyfirstfioriapp.Main", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf zmyfirstfioriapp.Main
*/
	onInit: function() {
		var oModel = new sap.ui.model.json.JSONModel();
		oModel.loadData("model/myData.json");
		sap.ui.getCore().setModel(oModel);
	},
	clickMe: function(){
		//Step 1: Access the object of app control
		var oApp = sap.ui.getCore().byId("idApp");
		//Step 2: Fire the code to navigate to second view from first view
		oApp.to("idView2","flip");
	},
	listItemPress: function(oEvent){
		var sPath = oEvent.getParameter("listItem").getBindingContextPath();
		var oView2 = sap.ui.getCore().byId("idView2");
		oView2.bindElement(sPath);
		this.clickMe();
		console.log(sPath);
	},
	deleteItem: function(oEvent){
		//Step 1: Access the object of the item to be deleted
		var oItem = oEvent.getParameter("listItem");
		//Step 2: Access the object of List Control
		var oList = oEvent.getSource();
		//Step 3: Tell the list control to delete the item
		oList.removeItem(oItem);
	},
	searchValue: function(oEvent){
		var searchString = oEvent.getParameter("query");
		var oFilter = new sap.ui.model.Filter("name", 
				sap.ui.model.FilterOperator.Contains,
				searchString);
		var oFilter1 = new sap.ui.model.Filter("color",
				sap.ui.model.FilterOperator.Contains,
				searchString);
		var oMainFilter = new sap.ui.model.Filter(
				{
					filters: [oFilter,oFilter1],
					and: false
				}
		);
		
		var oList = sap.ui.getCore().byId("myList");
		var aFilter = [oMainFilter];
		
		oList.getBinding("items").filter(aFilter);
		
	},
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf zmyfirstfioriapp.Main
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf zmyfirstfioriapp.Main
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf zmyfirstfioriapp.Main
*/
//	onExit: function() {
//
//	}

});