sap.designstudio.sdk.Component.subclass("com.ta.sample.chatwindow.chat", function() {

	//var that = this;
	var box = null;

	this.init = function() {
		
	
		
	};

	this.afterUpdate = function() {
		var html = '<div id="chat_div"></div><hr /><div id="log"></div>';
		this.$().html(html);
		createChatbox();
		
	};
	function createChatbox()
	{
		alert("in chat box");
		box = $("#chat_div").chatbox(
				{
					/*
						unique id for chat box
					*/
					id:"Runnable",
                    user:
					{
						key : "value"
					},
					/*
						Title for the chat box
					*/
					title : "Runnable User",
					/*
						messageSend as name suggest,
						this will called when message sent.
						and for demo we have appended sent message to our log div.
					*/
					messageSent : function(id, user, msg)
					{
						$("#log").append(id + " said: " + msg + "<br/>");
                        $("#chat_div").chatbox("option", "boxManager").addMsg(id, msg);
                    }
				});
	}

});
