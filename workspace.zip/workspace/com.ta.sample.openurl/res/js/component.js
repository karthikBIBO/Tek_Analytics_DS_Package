sap.designstudio.sdk.Component.subclass("com.ta.sample.openurl.Openurl", function() {

	var that = this;


	this.init = function() {
	};

	this.afterUpdate = function() {
		urlWithParameters();
	};

	var finalUrl = null;
	var triggerVal = null;
	var lParameters = null;
	var targetVal= null;
	
	this.url = function(value) {
		if (value == undefined) {
			return finalUrl;
		} else {
			finalUrl = value;
			return this;
		}
	};	
	
	this.trigger = function(value) {
		if (value == undefined) {
			return triggerVal;
		} else {
			triggerVal = value;
			return this;
		}
	};
	
	this.parameters = function(value) {
		if (value == undefined) {
			return lParameters;
		} else {
			lParameters = value;
			return this;
		}
	};
	
	this.target = function(value) {
		if (value == undefined) {
			return targetVal;
		} else {
			targetVal = value;
			return this;
		}
	};
	

	function urlWithParameters() {
		
		if(finalUrl != "" && triggerVal == "GO") {
			// read local created new Notifications
			if((lParameters != undefined || lParameters != undefined) && lParameters != "" && lParameters != "<delete>"){
				var lParametersArray = JSON.parse(lParameters);
				if(lParametersArray.length > 0) {
					finalUrl= finalUrl + "?";
				}
				for (var i = 0; i < lParametersArray.length; i++) {
					finalUrl = finalUrl + encodeURIComponent(lParametersArray[i].name) + "=" + encodeURIComponent(lParametersArray[i].value) + "";
					
					if(lParametersArray.length - 1 > i) {
						finalUrl = finalUrl + "&";	
					}
				}
			}
			// by by...
			if(targetVal=="current"){
				window.location = finalUrl;
			}
			else if(targetVal=="new"){
				window.open(finalUrl, "_blank", "x=y");
			}
			return;
		}
	}


});
