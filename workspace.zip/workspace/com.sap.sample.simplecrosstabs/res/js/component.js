sap.designstudio.sdk.Component.subclass("com.sap.sample.simplecrosstab.SimpleCrosstabs", function() {


	var DATA_DIM = "data-dim-";

	var that = this;

	var data = null;
	var visSelection = {};

	

	
	this.init = function() {
		this.$().addClass(CSS_CLASS_DIV);
		this.$().css("overflow-x", "scroll");
		this.$().css("overflow-y", "scroll");
	};

	this.afterUpdate = function() {
		alert("after update.. doing nothing ");
	};

	// property setter/getter functions



	this.visSelection = function(value) {};
});
