sap.designstudio.sdk.Component.subclass("com.sap.sample.openurl.Openurl", function() {

	var that = this;


	this.init = function() {};

	this.afterUpdate = function() {
		openUrl();
		
	};

	var finalUrl = "";
	
	this.url = function(value) {
		if (value == undefined) {
			return finalUrl;
		} else {
			finalUrl = value;
			return this;
		}
	};	

	function openUrl(){
		alert("in openUrl --finalUrl"+finalUrl);
		if(finalUrl!="")
			{
				window.open=finalUrl;
				return;
			}
		
	}

});
