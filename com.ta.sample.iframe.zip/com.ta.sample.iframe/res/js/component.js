sap.designstudio.sdk.Component.subclass("com.ta.sample.iframe.frame", function() {

	var meta_data 				= null;
	var saveUrlDimension 		= null;

	this.init = function() {
	};

	this.afterUpdate = function() {
		var html = '<iframe src="'+saveUrlDimension+'" width="auto" height="auto"></iframe>';			
		this.$().html(html);
	};

	// property setter/getter functions. Names have to match .ztl file defintions and
	// vice versa if intended to expose to other Design Studio components	
	this.metadata = function(value) {
		if (value === undefined) {
			return meta_data;
		} else {
			meta_data = value;
			return this;
		}
	};
	
	this.urldimension = function(value) {
		if (value === undefined) {
			return saveUrlDimension;
		} else {
			saveUrlDimension = encodeURI(value);
			return this;
		}
	};


});
